// This file is deprecated. The college list is now fetched dynamically 
// from the 'colleges' table in the database within RegisterPage.tsx.
export const indianColleges = [];
