import React from 'react';

// This is a placeholder component to prevent build errors from an empty file.
// It is not currently used in the application.
const CreatePostModal: React.FC = () => {
    return null;
};

export default CreatePostModal;