import React from "react";

const VerificationPage: React.FC = () => {
  return (
    <div>
      <h1>Verification Page</h1>
      {/* Add your verification content here */}
    </div>
  );
};

export default VerificationPage;
